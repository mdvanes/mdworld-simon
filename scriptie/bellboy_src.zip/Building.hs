module Building where

import Graphics.UI.WXCore
import Graphics.UI.WX
import Random

-- variables for the simulator
buildingColor :: Color
buildingColor = black

hoistwayszone0 dc viewRect (x1,y1,x2,y2) 1 bot =
   do
   hoistwaypair dc viewRect (x1, y1, x2, y2) bot
hoistwayszone0 dc viewRect (x1,y1,x2,y2) n bot =
   do
   hoistwaypair dc viewRect (x1, y1, x2, y2) bot
   hoistwayszone0 dc viewRect (x1 + 32, y1 - 40, x2 + 32, y2 - 40) (n - 1) bot
   
hoistwaypair dc viewRect (x1,y1,x2,y2) y3 =
   do
   -- halfservice
   line dc (pt x1 y3) (pt x2 y1) [color := lightgrey, penWidth := 15, penKind := PenSolid, penCap := CapButt]
   line dc (pt (x1 + 16) y3) (pt (x2 + 16) y1) [color := lightgrey, penWidth := 15, penKind := PenSolid, penCap := CapButt]
   -- fullservice
   line dc (pt x1 y1) (pt x2 y2) [color := black, penWidth := 15, penKind := PenSolid, penCap := CapButt]
   line dc (pt (x1 + 16) y1) (pt (x2 + 16) y2) [color := black, penWidth := 15, penKind := PenSolid, penCap := CapButt]


onpaint :: (DC a) -> t -> IO ()
onpaint dc viewRect
      = do -- building
           --   leftwall
           line dc (pt 145 10) (pt 145 410) [color := black]
           --   rightwall
           line dc (pt 400 10) (pt 400 410) [color := black]
           -- zone 0
           drawText dc "lobby, floor 1" (pt 83 399) [fontSize := 7]
           --   hoistways zone 0
           hoistwayszone0 dc viewRect (155, 370, 155, 410) 4 410
           -- zone 1
           drawText dc "skylobby, floor 41" (pt 60 239) [fontSize := 7]
           --   hoistways zone 1
           hoistwayszone0 dc viewRect (155, 210, 155, 250) 3 250
           -- zone 2
           drawText dc "skylobby, floor 71" (pt 60 119) [fontSize := 7]
           --   hoistways zone 2
           hoistwayszone0 dc viewRect (155, 90, 155, 130) 3 130
           -- hoistways shuttles
           --       hoistway elevator SA, shuttle, floors 1, 41
           line dc (pt 310 246) (pt 310 410) [color := lightgrey, penWidth := 15, penKind := PenSolid, penCap := CapButt]
           --       hoistway elevator SB, shuttle, floors 1, 41
           line dc (pt 326 246) (pt 326 410) [color := lightgrey, penWidth := 15, penKind := PenSolid, penCap := CapButt]
           --       hoistway elevator SC, shuttle, floors 1, 41, 71
           line dc (pt 342 126) (pt 342 410) [color := lightgrey, penWidth := 15, penKind := PenSolid, penCap := CapButt]
           --       hoistway elevator SD, shuttle, floors 1, 41, 71
           line dc (pt 358 126) (pt 358 410) [color := lightgrey, penWidth := 15, penKind := PenSolid, penCap := CapButt]
           --   rooftop (no function in the simulator, doesn't count as a floor)
           line dc (pt 146 9) (pt 400 9) [color := black]
           --   lobby
           line dc (pt 146 408) (pt 400 408) [color := red, penWidth := 4, penKind := PenSolid, penCap := CapButt]
           --   skylobby 1
           line dc (pt 146 248) (pt 400 248) [color := red, penWidth := 4, penKind := PenSolid, penCap := CapButt]
           --   skylobby 2
           line dc (pt 146 128) (pt 400 128) [color := red, penWidth := 4, penKind := PenSolid, penCap := CapButt]
-- end onpaint

