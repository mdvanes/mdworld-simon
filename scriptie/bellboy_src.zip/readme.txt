Usage (on commandline):

bellboy <iterations> <mode> <visual>
  iteration:     amount of ticks to iterate, any integer will do, but is tested from 10000 to 500000
  mode:          choose between one of these (case sensitive): run learn SAA SAL
  visual:        toggles the GUI, choose between: on off

NOTE: when you choose "run" for mode, a file with weights is required, named "in_weights.txt". This file can easily be
created by first running with "learn" as mode, which outputs a file named "out_weights.txt", rename this to
"in_weights.txt".

The included file "out_weights_500000.txt" is a weights-file, with weights trained on 500,000 iterations. This
can be used as input for running by renaming it to "in_weights.txt". The train phase for that 500,000 iterations took 
approximately 3 hours on my AMD Athlon XP 2400/Windows XP system.

For Windows users:
   Unpack the *entire* archive to one folder, and run the executable with the commandline. The GUI is only guaranteed
   for Windows XP.

For Linux users:
   Please put the included libwxc-gtk2.4.2-0.7.so in your /usr/lib/ directory.
   You will need GTK 2.4.2 or higher to use the GUI.

For Mac OS X users:
   Please put the file libwxc-mac2.5.2-0.7.dylib in the /usr/local/wxhaskell/lib directory. Root access may be required.
   The executable for the OS X version of this program is named a.out instead of bellboy for now, therefore any
   occurences of bellboy above must be replaced by a.out . The OS X compile was performed by Arjan van IJzendoorn,
   for which I thank him. Because I don't have a Mac, I cannot say anything about how this will work/show on a Mac.


-- 24 june 2004
   Martin van Es
