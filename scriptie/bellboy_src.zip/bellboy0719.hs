module Main where

import Graphics.UI.WXCore
import Graphics.UI.WX
import Building
import Random
import List
import Time
import IOExts
import System
import System.CPUTime
import Migrateweights

data Action
   = Stop
   | Continue
   deriving (Show, Eq)
   
data Direction
   = Up
   | Down
   deriving (Show, Eq)

data Luser = Luser
   { arriv         :: !Float           -- arrival floor
   , dest          :: !Float           -- destination floor
   , temp          :: !Float           -- temporary floor
   , wait          :: !Float           -- wait time
   }
   deriving (Show, Eq)

data LiftState = LiftState
   { direction     :: !Direction
   , load          :: !Float
   , plistLocal    :: ![Luser]
   , plistBoarded  :: ![Luser]
   , floorPos      :: !Float
   , action        :: !Action
   , holdPos       :: !Int
   }
   deriving (Show, Eq)

data ProgramState = ProgramState
    { arch         :: !(Int, Int, Int)
    , eta          :: !Float
    , gamma        :: !Float
    , tick         :: !Int
    , liftSpecific :: ![LiftState]
    , weights      :: ![[[Float]]]
    , result       :: !(Float, Float, Float) -- (sumWaittime, sumSquared, amountP)
    , maxticks     :: !Int
    , phase        :: !String
    , amountLifts  :: !Int
    , interzonetraffic :: ![Luser]
    }
    deriving (Show, Eq)

hyperstrict :: Eq a => a -> b -> b
hyperstrict x y = seq (x==x) y

sometimesHyperStrict :: Eq a => Int -> a -> b -> b
sometimesHyperStrict counter x y 
    | counter `mod` 100 == 0 = hyperstrict x y
    | otherwise              = y

main :: IO ()
main =
   do
   args <- getArgs
   initAgent args

initAgent :: [String] -> IO ()
initAgent [maxticks2, phase1, visual]
   | (phase1 /= "learn") && (visual == "off") =
       do
       before <- getClockTime
       tsPre <- toCalendarTime before
       irl <- infiniteRandoms
       let timestamp = (show (ctYear tsPre)) ++ (show (ctYDay tsPre)) ++ (show (ctHour tsPre)) ++ (show (ctMin tsPre)) ++ (show (ctSec tsPre))
       -- putStr ("Timestamp is: " ++ timestamp ++ "\n")
       fileContents <- readFile "in_weights.txt" -- datafilename
       let importedWeights = importParser fileContents
       let liftSpecific1 = createLiftSpecific amountLifts1 irl -- (replicate amountLifts1 lift)
       let irl2 = drop 24 irl
       let initialProgramState = ProgramState {arch = archL, eta = etaL, gamma = gamma1, tick = tick1, liftSpecific = liftSpecific1, weights = importedWeights, result = (0,0,0), maxticks = maxticks1, phase = phase1, amountLifts = amountLifts1, interzonetraffic = [] }
       noVisual irl2 initialProgramState timestamp
       after <- getClockTime
       -- let time1 = ("\nTime taken: " ++ show (diffClockTimes after before) ++ "\n\n")
       let timeD = (diffClockTimes after before)
       let time1 = ((show (tdHour timeD)) ++ " " ++ (show (tdMin timeD)) ++ " " ++ (show (tdSec timeD)))
       -- putStr ("\n-----------------------------------------\n")
       putStr time1
   | phase1 == "learn" =
       do
       before <- getClockTime
       irl <- infiniteRandoms
       let liftSpecific1 = createLiftSpecific amountLifts1 irl
       let initialProgramState = ProgramState {arch = archL, eta = etaL, gamma = gamma1, tick = tick1, liftSpecific = liftSpecific1, weights = weightsL, result = (0,0,0), maxticks = maxticks1, phase = phase1, amountLifts = amountLifts1, interzonetraffic = [] }
       let irl2 = drop 24 irl
       dcaInit irl2 initialProgramState
       after <- getClockTime
       -- let time1 = ("\nTime taken: " ++ show (diffClockTimes after before) ++ "\n\n")
       let timeD = (diffClockTimes after before)
       let time1 = ((show (tdDay timeD)) ++ " " ++ (show (tdHour timeD)) ++ " " ++ (show (tdMin timeD)) ++ " " ++ (show (tdSec timeD)))
       -- putStr ("\n-----------------------------------------\n")
       putStr "learn, , , , "
       putStr time1
   | phase1 == "run" =
       do
       before <- getClockTime
       fileContents <- readFile "in_weights.txt" -- datafilename
       irl <- infiniteRandoms
       let importedWeights = importParser fileContents
       let liftSpecific1 = createLiftSpecific amountLifts1 irl
       let irl2 = drop 24 irl
       let initialProgramState = ProgramState {arch = archL, eta = etaL, gamma = gamma1, tick = tick1, liftSpecific = liftSpecific1, weights = importedWeights, result = (0,0,0), maxticks = maxticks1, phase = phase1, amountLifts = amountLifts1, interzonetraffic = [] }
       putStr (show liftSpecific1)
       start (bellboy irl2 initialProgramState)
       after <- getClockTime
       let time1 = ("\nTime taken: " ++ show (diffClockTimes after before) ++ "\n\n")
       putStr ("\n-----------------------------------------\n")
       putStr time1
   | (phase1 == "SAL") || (phase1 == "SAA") =
       do
       before <- getClockTime
       irl <- infiniteRandoms
       let liftSpecific1 = createLiftSpecific amountLifts1 irl
       let irl2 = drop 24 irl
       let initialProgramState = ProgramState {arch = archL, eta = etaL, gamma = gamma1, tick = tick1, liftSpecific = liftSpecific1, weights = weightsL, result = (0,0,0), maxticks = maxticks1, phase = phase1, amountLifts = amountLifts1, interzonetraffic = [] }
       start (bellboy irl2 initialProgramState)
       after <- getClockTime
       let time1 = ("\nTime taken: " ++ show (diffClockTimes after before) ++ "\n\n")
       putStr ("\n-----------------------------------------\n")
       putStr time1
   | otherwise =
       putStr noArgMessage
   where maxticks1 = read maxticks2 :: Int
         archL = (15,20,2) -- direction/load/pos per lift, arriv/dest for passenger, one bias
         etaL = 0.01
         gamma1 = 0.98
         tick1 = (-1)
         lift = LiftState { direction = Down, load = 0.0, plistLocal = [], plistBoarded = [], floorPos = 40, action = Stop, holdPos = 0}
         amountLifts1 = 24 :: Int
         weightsL  = []
         randomSeed = fromInteger (unsafePerformIO getCPUTime)  -- 12 --
initAgent _ =
   putStr noArgMessage

createLiftSpecific :: Int -> [Float] -> [LiftState]
createLiftSpecific 0 _ = []
createLiftSpecific n irl1
   | (n >= 5) =
      createLiftSpecific1 n irl1
   | (n >= 3) =   let randomint = (head irl1)
                      initialposition = fromIntegral ((round (40 * randomint)) + 1) :: Float
                      initialLiftState = LiftState { direction = Down, load = 0.0, plistLocal = [], plistBoarded = [], floorPos = initialposition, action = Stop, holdPos = 0}
                  in  initialLiftState:createLiftSpecific (n - 1) (tail irl1)
   | otherwise =  let randomint = (head irl1)
                      initialposition = fromIntegral ((round (70 * randomint)) + 1) :: Float
                      initialLiftState = LiftState { direction = Down, load = 0.0, plistLocal = [], plistBoarded = [], floorPos = initialposition, action = Stop, holdPos = 0}
                  in  initialLiftState:createLiftSpecific (n - 1) (tail irl1)

createLiftSpecific1 :: Int -> [Float] -> [LiftState]
createLiftSpecific1 n irl1 =
       let n1 = calculatezone1 (25 - n)
           randomint = (head irl1)
           scaleri = round ((9 * randomint) + 1)
           initialposition = fromIntegral (scaleri + ((10 * n1))) :: Float
           initialLiftState = LiftState { direction = Down, load = 0.0, plistLocal = [], plistBoarded = [], floorPos = initialposition, action = Stop, holdPos = 0}
       in  initialLiftState:createLiftSpecific (n - 1) (tail irl1)

calculatezone1 n = [0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12]!!(n - 1)

infiniteRandoms :: IO [Float]
infiniteRandoms = do
    gen <- getStdGen
    return (randomRs (0.0,1.0 :: Float) gen)

noArgMessage :: String
noArgMessage = "usage: bellboy <iterations> <mode> <visual> \n  iteration:     amount of ticks to iterate\n  mode:          run or learn (or SAA or SAL)\nNOTE: when (mode = run) a file with weights is required, named in_weights.txt\nThis file can easily be created by first running with (mode = learn), which\noutputs a file named out_weights.txt, rename this to in_weights.txt\n  visual:         on/off, shows visual feedback or just results\n"

--------------------- start GUI
-- Display this text when clicking the "About" button.
aboutText :: String
aboutText = "Version 1.7 of Bellboy\n 19 july 2004"

bellboy :: [Float] -> ProgramState -> IO ()
bellboy irl programState
  = do irlVar      <- varCreate irl
       pSVar       <- varCreate programState
       passengers  <- varCreate [((1::Integer), (1::Integer), (1::Integer), (0::Integer))]
       let liftstates = liftSpecific programState -- pS1
       let liftpositions = extractPositions liftstates
       putStr "bellboy "
       let liftpoints = pointlist liftpositions 0
       -- putStr (show liftpoints)
       -- putStr (show liftpositions)
       -- putStr "\n"
       liftpos     <- varCreate liftpoints
       loads       <- varCreate (replicate 22 0)
       waiting     <- varCreate (replicate 100 0)
       -- the application frame
       f <- frame [text := "Bellboy", clientSize := sz 500 500]
       -- create the window that contains the graphics, start painting the lifts
       p <- panel f [on paint := paintLift liftpos loads waiting pSVar, bgcolor := white]
       -- fill in the windowlayout, such as menu and statusbar
       windowDesign f p
       -- create a timer, on each tick it advances the lift to its next position
       -- and start the timer (was 100 msec now 63 msec to get the elevators to a speed of 12m/s).
       -- nextFrame contains all functions that must be repeated
       t <- timer f [interval := 63, on command := nextFrame p liftpos loads waiting passengers irlVar pSVar]
       return ()

pointlist :: [Float] -> Int -> [Point]
pointlist [] _ = []
pointlist liftpositions i =
   (floorToPoint (head liftpositions) i):(pointlist (tail liftpositions) (i+1))

-- design of window, including menu and statusbar
windowDesign :: (Widget w) => Frame a -> w -> IO ()
windowDesign f p
  = do -- create file menu
       file   <- menuPane      [text := "&File"]
       quit   <- menuQuit file [help := "Quit the demo", on command := close f]
       -- create Help menu
       hlp    <- menuHelp      []
       about  <- menuAbout hlp [help := "About Bellboy"]

       -- create statusbar field
       status <- statusField   [text := "Welcome to Bellboy"]

       -- set the statusbar and menubar
       set f [ statusBar := [status]
             -- , menuBar   := [file,random,hlp]
             , menuBar   := [file,hlp]
             -- as an example, put the menu event handler for an about box on the frame.
             ,on (menu about) := infoDialog f "About Bellboy" aboutText
             -- ,on (menu test)  := infoDialog f "Menu titel" "Menu text"
             , layout := fill $widget p
             ]
-- end windowDesign

-- exported onpaint, loaded with building
nextFrame :: (Integral a1) => Window a -> Var [Point] -> Var [a1] -> Var [Int] -> t -> Var [Float] -> Var ProgramState -> IO ()
nextFrame w liftpos loads waiting passengers irlVar pSVar =
   do
   oldState <- varGet pSVar
   if (tick oldState) == (maxticks oldState)
    then return () -- windowRefresh w False
    else nextFrame1 w liftpos loads waiting passengers irlVar pSVar

nextFrame1 :: (Integral a) => Window a1 -> Var [Point] -> Var [a] -> Var [Int] -> t -> Var [Float] -> Var ProgramState -> IO ()
nextFrame1 w liftpos loads waiting _ irlVar pSVar =
   do
   oldState <- varGet pSVar
   irl <- varGet irlVar
   let (newIrl, newProgramState) = dcaRun irl oldState -- oldState {tick = 1}
   varSet pSVar newProgramState
   -- get and display new positions
   let liftstates = liftSpecific newProgramState
   let liftpositions = extractPositions liftstates
   let liftpoints = pointlist liftpositions 0
   -- extract loads
   let liftloads = extractLoads liftstates
   -- extract waiting users per floor
   let waitingp  = extractWaitpfloor liftstates (replicate 100 0)
   -- update variables
   varSet liftpos liftpoints
   varSet irlVar newIrl
   varSet loads liftloads
   varSet waiting waitingp
   windowRefresh w False

extractWaitpfloor :: [LiftState] -> [Int] -> [Int]
extractWaitpfloor [] wpf = wpf
extractWaitpfloor liftstates currentwaitpfloor =
   let plist = plistLocal (head liftstates)
       waitpfloor = convertPlistToPPF plist [1..100]
       newwaitpfloor = zipWith (+) currentwaitpfloor waitpfloor
   in  extractWaitpfloor (tail liftstates) newwaitpfloor

-- convert a plistlocal to the amount of waiting passengers per floor
convertPlistToPPF :: [Luser] -> [Float] -> [Int]
convertPlistToPPF plist zone =
   let pasgOnFloor = (filter (\x -> (arriv x)==(head zone)) plist)
   in  (length pasgOnFloor):(convertPlistToPPF plist (tail zone))

extractLoads :: (Integral a) => [LiftState] -> [a]
extractLoads [] = []
extractLoads liftstates =
   (round (load (head liftstates))):(extractLoads (tail liftstates))

extractPositions :: [LiftState] -> [Float]
extractPositions [] = []
extractPositions liftstates =
   (floorPos (head liftstates)):(extractPositions (tail liftstates))

-- paint the lifts
-- paintLift :: (Eq [a1], Show a1) => Var [Point] -> Var [a1] -> Var [Int] -> Var ProgramState -> DC a -> t -> IO ()
paintLift liftpos loads waiting pSVar dc viewRect
  =  do -- dcClear dc
     oldState <- varGet pSVar
     let (totwait, totsqwait, nrUsers) = result oldState
     let avgwait1 = (totwait / nrUsers) * 0.063
     let sqwait1  = (sqrt (totsqwait / nrUsers)) * 0.063
     let tickNow = tick oldState
     let secsNow = (round ((fromIntegral tickNow) * 0.063))::Integer
     onpaint dc viewRect
     vliftpos <- varGet liftpos
     vloads   <- varGet loads
     vwaiting <- varGet waiting
     drawText dc "avg. waittime (seconds):" (pt 10 10) [fontSize := 7]
     drawText dc (show avgwait1) (pt 15 23) [fontSize := 7]
     drawText dc "RMS waittime:" (pt 10 35) [fontSize := 7]
     drawText dc (show sqwait1) (pt 15 48) [fontSize := 7]
     drawText dc ("tick: " ++ (show tickNow)) (pt 10 70) [fontSize := 7]
     drawText dc ("second: " ++ (show secsNow)) (pt 10 90) [fontSize := 7]
     drawWaiting vwaiting (405, 408) dc viewRect
     drawLoads dc viewRect vloads (150, 390)
     dcWithBrushStyle dc (BrushStyle BrushSolid red) $
       mapM_ (drawLift dc) vliftpos

drawWaiting :: [Int] -> (Int, Int) -> DC a -> t -> IO ()
drawWaiting vwaiting (x1, y1) dc viewRect
   | (length vwaiting)==1 =
       do
       let floorwaiting = (head vwaiting)
       let x2 = x1 + (scalefactor*floorwaiting)
       line dc (pt x1 y1) (pt x2 y1) [color := blue, penWidth := 3, penKind := PenSolid, penCap := CapButt]
   | otherwise =
       do
       let floorwaiting = (head vwaiting)
       let x2 = x1 + (scalefactor*floorwaiting)
       line dc (pt x1 y1) (pt x2 y1) [color := blue, penWidth := 3, penKind := PenSolid, penCap := CapButt]
       drawWaiting (tail vwaiting) (x1, (y1 - 4)) dc viewRect
   where scalefactor = 2

-- drawLoads :: (Show a1, Eq [a1]) => DC a -> t -> [a1] -> (Int, Int) -> IO ()
drawLoads dc viewRect vloads (x,y)
   | (tail vloads)==[] =
      do
      drawText  dc (show (head vloads)) (pt 356         390) [fontSize := fontsize1, textColor := penkleur]
   | (length vloads)<4 =
      do
      drawText  dc (show (head vloads)) (pt   x         390) [fontSize := fontsize1, textColor := penkleur]
      drawLoads dc viewRect (tail vloads) (x+16, y)
   | (length vloads)==4 =
      do
      drawText  dc (show (head vloads)) (pt 308         390) [fontSize := fontsize1, textColor := penkleur]
      drawLoads dc viewRect (tail vloads) (324, y)
   | (length vloads)<10 =
      do
      drawText  dc (show (head vloads)) (pt   x zone2labely) [fontSize := fontsize1, textColor := penkleur]
      drawLoads dc viewRect (tail vloads) (x+16, y)
   | (length vloads)==10 =
      do
      drawText  dc (show (head vloads)) (pt 150 zone2labely) [fontSize := fontsize1, textColor := penkleur]
      drawLoads dc viewRect (tail vloads) ( 166, y)
   | (length vloads)<16 =
      do
      drawText  dc (show (head vloads)) (pt   x zone1labely) [fontSize := fontsize1, textColor := penkleur]
      drawLoads dc viewRect (tail vloads) (x+16, y)
   | (length vloads)==16 =
      do
      drawText  dc (show (head vloads)) (pt 150 zone1labely) [fontSize := fontsize1, textColor := penkleur]
      drawLoads dc viewRect (tail vloads) ( 166, y)
   | otherwise =
      do
      drawText  dc (show (head vloads)) (pt   x           y) [fontSize := fontsize1, textColor := penkleur]
      drawLoads dc viewRect (tail vloads) (x+16, y)
   where fontsize1 = 5
         penkleur = red
         zone1labely = 227
         zone2labely = 107

-- given a point, draw an elevator (as a blue, 4px high stripe)
drawLift :: DC a -> Point -> IO ()
drawLift dc pt1@(Point x y) =
   line dc (Point x z) pt1 [color := blue, penWidth := 4, penKind := PenSolid, penCap := CapButt]
   where z = y - 4

-- floorToPoint floor elevatornr
floorToPoint :: Float -> Int -> Point
floorToPoint f n
  | n < 8  =
     let n1 = n
         x = 154 + (n1 * 16)
     in  Point x (round (410 - ((f * 4) - 4)))
  | n < 14 =
     let n1 = n - 8
         x = 154 + (n1 * 16)
     in  Point x (round (410 - ((f * 4) - 4)))
  | n < 20 =
     let n1 = n - 14
         x = 154 + (n1 * 16)
     in  Point x (round (410 - ((f * 4) - 4)))
  | n==20 =
     Point 310 (round (410 - ((f * 4) - 4)))
  | n==21 =
     Point 326 (round (410 - ((f * 4) - 4)))
  | n==22 =
     Point 342 (round (410 - ((f * 4) - 4)))
  | n==23 =
     Point 358 (round (410 - ((f * 4) - 4)))
  | otherwise = error "no lift found"

-- calccoord cur dest -- calculate coordinates from cur(rent) to dest(ination)
calccoord :: Point -> Point -> [Point]
calccoord cur@(Point x y) dest1@(Point x1 y1)
          | cur == dest1 = [cur]
          | ((y < y1) && (x == x1)) = reverse (calccoord1 x y y1 [])
          | ((y > y1) && (x == x1)) = calccoord1 x y1 y []
          | otherwise = error ("Ja hallo hij is of hetzelfde, of groter of kleiner! Of verschillen misschien de liftnummers?")

calccoord1 :: Int -> Int -> Int -> [Point] -> [Point]
calccoord1 x f t ps
          | ps==[] = calccoord1 x (f+1) t [Point x f]++ps
          | (head ps)==(pt x t) = ps
          | otherwise = calccoord1 x (f+1) t [Point x f]++ps

-- random Passengers creates a sequence of floors (presumably called by a passenger)
randomPsgs :: Int -> [Float] -> [[Point]]
randomPsgs lnr list = zipWith calccoord fl fl2
                      where floorToPoint1 a b = floorToPoint b a
                            list2 = (drop 1 list)++[head list]
                            fl = map (floorToPoint1 lnr) list
                            fl2 = map (floorToPoint1 lnr) list2

-- create an IO [Int] of random Ints between lo and hi

someRandoms1 :: Int -> (Int, Int) -> IO [Int]
someRandoms1 0 _ = return []
someRandoms1 n (lo, hi) = do
    x <- randomRIO (lo, hi)
    xs <- someRandoms1 (n-1) (lo, hi)
    return (x:xs)

-- creating 4-tuples for (arrivalfloor, tempfloor, destinationfloor, time)
tuple4 :: a -> b -> c -> d -> (a,b,c,d)
tuple4 w x y z = (w,x,y,z)

-- updating time variable (as last parameter of) 4-tuple with 63 msec
updatetime63 :: (Num a) => (t, t1, t2, a) -> (t, t1, t2, a)
updatetime63 (w,x,y,z) = (w,x,y,(z+63))

addToSublist :: Int -> [a] -> [[a]] -> [[a]]
addToSublist n l1 lol = (take (n-1) lol)++ [lol!!(n-1) ++ l1] ++ (drop n lol)

--------------------- end GUI
dcaInit :: [Float] -> ProgramState -> IO ()
dcaInit irl programState =
   do
   let newProgramState = dca irl programState
   let weights1 = weights newProgramState
   let pweights1 = exportParser weights1
   writeFile ("out_weights.txt") pweights1
   -- putStr (show weights1)

noVisual :: [Float] -> ProgramState -> t -> IO ()
noVisual irl programState timestamp
   | (tick programState)==(maxticks programState) =
       do
       let (totwait, totsqwait, nrUsers) = (result programState)
       let avgwait = (totwait   / nrUsers) * 0.063
       let avgsqwait1  = (totsqwait / nrUsers)
       let avgsqwait  = avgsqwait1 * 0.063
       let rmswait = (sqrt avgsqwait1) * 0.063
       -- let results = ("Avg. waittime (seconds): " ++ (show avgwait) ++ "\nAvg. sq. waittime:       " ++ (show avgsqwait) ++ "\nRMS waittime:            " ++ (show rmswait) ++ "\nNumber of users:         " ++ (show nrUsers))
       let results = ("\n" ++ (show (phase programState))++ ", " ++ (show avgwait) ++ ", " ++ (show rmswait) ++ ", " ++ (show nrUsers) ++ ", ")
       -- appendFile ("stateinfo_" ++ (timestamp) ++ ".txt") results
       putStr results
   | otherwise =
       do
       let (newIrl, newPS) = dcaRun irl programState
       -- let stateinfo = dcaPrinter2 (tick newPS) (liftSpecific newPS)
       -- appendFile ("stateinfo_" ++ (timestamp) ++ ".txt") stateinfo
       -- noVisual newIrl newPS timestamp
       sometimesHyperStrict (tick programState) (newPS :: ProgramState) $
                noVisual newIrl newPS timestamp

initOla1 :: [Float] -> (Int, Int, Int) -> ([Float], LiftState)
initOla1 irl _ =
   let -- non-input parameters
       initLoad = 0 -- always start of with an empty elevator
       initPlistBoarded = [] -- as noted, elevator is empty
       initDirection = Up -- up
       initPosition = fromIntegral ((round ((4*(head irl))+1))::Integer)
       stateLift = LiftState { direction = initDirection, load = initLoad, plistLocal = [], plistBoarded = initPlistBoarded, floorPos = initPosition, action = Stop, holdPos = 0}
       result1 = (drop 1 irl, stateLift)
   in  result1

-----------
-- create an IO [Int] of random Ints between lo and hi
{-
unsafeSomeRandoms :: Int -> [Float]
unsafeSomeRandoms n = unsafePerformIO (someRandoms n (0.0, 1.0))

someRandoms :: Int -> (Float, Float) -> IO [Float]
someRandoms 0 _ = return []
someRandoms n (lo, hi) = do
    x <- randomRIO (lo, hi)
    xs <- someRandoms (n-1) (lo, hi)
    return (x:xs)
-}
-----------
initialLiftstates :: [Float] -> (Int,Int,Int) -> Int -> [LiftState] -> ([Float], [LiftState])
initialLiftstates irl _ 0 temp1 =
    (irl, temp1)
initialLiftstates irl arch1 n temp1 =
    let (irl1, stateLift) = initOla1 irl arch1
    in  initialLiftstates irl1 arch1 (n-1) (stateLift:temp1)

dcaRun :: [Float] -> ProgramState -> ([Float], ProgramState)
dcaRun irl pS =
   let (irl1, newrandomplist) = newrandomp irl -- (createNRandompsg amountnewpsgN irl) -- list of passengers, each passenger of form [arrival, destination, 0 , 0]
       totalNewrandomplist = newrandomplist ++ (interzonetraffic pS)
       upperboundzones = ((fromIntegral (amountLifts pS)) / 2) * 10
       (liftSpecific_temp, nbList, interzonetraffic1) = olaBatch (liftSpecific pS) [1..(upperboundzones::Double)] ([], [], []) 1
       result1 = calcTotalWaittime nbList (result pS)
       pS_dcasrbatch = pS {liftSpecific = liftSpecific_temp}
       (irl2, plistLocal2, weights1) = dcaSubRuleBatch pS_dcasrbatch irl1 totalNewrandomplist
       -- (irl2, plistLocal2, weights1,_) = dcaSubRuleBatch (arch pS) (eta pS) (gamma pS) irl1 totalNewrandomplist (weights pS) liftSpecific_temp (phase pS) 0
       liftSpecific1 = updPlistsafterAsg plistLocal2 liftSpecific_temp
       ticknew = (tick pS) + 1
       newPS = pS { tick = ticknew, liftSpecific = liftSpecific1, weights = weights1, result = result1, interzonetraffic = interzonetraffic1}
   in  (irl2, newPS)

dca :: [Float] -> ProgramState -> ProgramState
dca irl pS
   {-
   | ((tick pS) == (-1)) && ((phase pS) == "run") =
       -- intialization step, no learning is done here
       let nZones = div (amountLifts pS) 2 -- number of zones (4 zones is floor 1 to 40)
           (irl1, liftSpecific1) = initialLiftstates irl (arch pS) (amountLifts pS) []
           ticks1 = 0
           (inp, hid, out) = (arch pS)
           -- use the importedweights from the file that was given as an parameter with the program: datafilename
           usedIrl = ((inp*hid)+(hid*out)) * nZones
           newPS = pS { tick = ticks1, liftSpecific = liftSpecific1 }
       in  seq newPS newPS
   -}
   | ((tick pS)==(-1)) && ((phase pS)=="learn") =
       -- intialization step, no learning is done here
       let nZones = div (amountLifts pS) 2 -- number of zones (4 zones is floor 1 to 40)
           (irl1, liftSpecific1) = initialLiftstates irl (arch pS) (amountLifts pS) []
           ticks1 = 0
           (inp, hid, out) = (arch pS)
           -- create random weights for all neural networks
           randomWeights = createRandomWeights nZones (arch pS) irl1
           usedIrl = ((inp*hid)+(hid*out)) * nZones
           irl2 = drop usedIrl irl1
           newPS = pS { tick = ticks1, liftSpecific = liftSpecific1, weights = randomWeights}
       in  dca irl2 newPS
   | (tick pS)==(maxticks pS) =
       pS
   | otherwise =
       -- begin: create new random passengers for this tick
       let (irl1, newrandomplist) = newrandomp irl -- (createNRandompsg amountnewpsgN irl) -- list of passengers, each passenger of form [arrival, destination, 0 , 0]
           totalNewrandomplist = newrandomplist ++ (interzonetraffic pS)
           -- end:   create new random passengers for this tick
           upperboundzones = ((fromIntegral (amountLifts pS)) / 2) * 10
           (liftSpecific_temp, nbList, interzonetraffic1) = olaBatch (liftSpecific pS) [1..(upperboundzones::Double)] ([], [], []) 1
           result1 = calcTotalWaittime nbList (result pS)
           pS_dcasrbatch = pS {liftSpecific = liftSpecific_temp}
           (irl2, plistLocal2, weights1) = dcaSubRuleBatch pS_dcasrbatch irl1 totalNewrandomplist
           -- (irl2, plistLocal2, weights1, _) = dcaSubRuleBatch (arch pS) (eta pS) (gamma pS) irl1 totalNewrandomplist (weights pS) liftSpecific_temp (phase pS) 0
           liftSpecific1 = updPlistsafterAsg plistLocal2 liftSpecific_temp
           ticknew = (tick pS) + 1
           newPS = pS { tick = ticknew, liftSpecific = liftSpecific1, weights = weights1, result = result1, interzonetraffic = interzonetraffic1}
       in sometimesHyperStrict (tick pS) (newPS :: ProgramState) $
                dca irl2 newPS

allUsers :: ProgramState -> IO ()
allUsers ps = putStrLn $ "Users: " ++ show (length
        (interzonetraffic ps ++ [ user | lift <- liftSpecific ps, user <- plistLocal lift ++ plistBoarded lift ]))

-- for each liftstate, replace its plistLocal by the updated plistLocal
updPlistsafterAsg :: [[Luser]] -> [LiftState] -> [LiftState]
updPlistsafterAsg _ [] = []
updPlistsafterAsg plistLocal2 liftSpecific_temp =
       let stateLiftNew = (head liftSpecific_temp) { plistLocal = (head plistLocal2) }
       in  stateLiftNew:(updPlistsafterAsg (tail plistLocal2) (tail liftSpecific_temp))

--olaBatch :: Show a => [LiftState] -> [a] -> ([LiftState], [Luser], [Luser]) -> Int -> ([LiftState], [Luser], [Luser])
olaBatch [] _ (liftSpecific_temp, nBlist, interzoneTraffic) _ =
   (liftSpecific_temp, nBlist, interzoneTraffic)
olaBatch liftSpecific1 zones (liftSpecific_temp, nBlist, interzoneTraffic) counter =
   let stateA = liftSpecific1!!0
       stateB = liftSpecific1!!1
       t = drop 2 liftSpecific1
       zone = calcZone counter -- take 10 zones
       (stateA_temp, newlyBoardedA) = ola zone stateA
       (stateB_temp, newlyBoardedB) = ola zone stateB
       currentfloorA = floorPos stateA
       currentfloorB = floorPos stateB
       -- filter all users that want to get off on current floor
       interzoneA = filter (\luser1 -> (dest luser1)==currentfloorA) (plistBoarded stateA)
       interzoneB = filter (\luser1 -> (dest luser1)==currentfloorB) (plistBoarded stateB)
       -- filter all users that want to get off on current floor and don't have this floor as final destination
       interzoneA1 = filter (\luser1 -> (temp luser1)/=0.0) interzoneA
       interzoneB1 = filter (\luser1 -> (temp luser1)/=0.0) interzoneB
       -- filter all users that don't have destfloor = 1, quick and dirty solution
       -- modify the users
       interzoneA2 = modifyInterzone interzoneA1 currentfloorA
       interzoneB2 = modifyInterzone interzoneB1 currentfloorB
   in  let par2   = drop 10 zones
           par3_1 = liftSpecific_temp ++ [stateA_temp] ++ [stateB_temp]
           par3_2 = nBlist ++ newlyBoardedA ++ newlyBoardedB
           par3_3 = interzoneTraffic ++ interzoneA2 ++ interzoneB2
           par4   = counter+1
       in sometimesHyperStrict counter (t, par2, par3_1, par3_2, par3_3) $
          sometimesHyperStrict counter (par4) $ 
        olaBatch 
            t 
            par2
            ( par3_1
            , par3_2
            , par3_3
            ) 
            par4

modifyInterzone :: [Luser] -> Float -> [Luser]
modifyInterzone [] _ = []
modifyInterzone interzonetraffic1 currentfloor =
   let mod0 = (head interzonetraffic1)
       mod1 = mod0 { arriv = currentfloor, wait = 0}
       mod2 = mod0 { arriv = currentfloor, temp= 0, wait = 0}
   in  if   temp mod0 == dest mod0
       then mod2:(modifyInterzone (tail interzonetraffic1) currentfloor)
       else mod1:(modifyInterzone (tail interzonetraffic1) currentfloor)

-- calculate the total waittime of all passengers that stopped waiting (i.e. that boarded a lift) for all lifts
calcTotalWaittime :: (Num b) => [Luser] -> (Float, Float, b) -> (Float, Float, b)
calcTotalWaittime list (a, b, n) =
   ((a1 + a), (b1 + b), n1)
   -- (a1, b1, (length list))
   where a1 = sum waittimes            -- sum of waittimes
         b1 = sum (map kwadraat waittimes) -- sum of squared waittimes
         kwadraat :: Float -> Float
         kwadraat x = x * x
         -- waittimes = (map (\x -> x!!3) list)
         waittimes = (map wait list)
         n1 = fromIntegral (length list) + n

-- create random weights for nZones amount of networks with architecture arch
createRandomWeights :: (Num a1, Fractional a) => a1 -> (Int, Int, Int) -> [a] -> [[[a]]]
createRandomWeights nZones arch1@(inp, hid, out) irl
   | nZones==0 = []
   | otherwise = randomWeights1:(createRandomWeights (nZones - 1) arch1 irl1)
   where totalunits = (inp*hid)+(hid*out)
         -- randomWeights = map (+(- 0.2)) (map (*0.4) (take totalunits irl)) -- interval [-0.2,0.2] for weights
         randomWeights = map (+(- 5)) (map (*10) (take totalunits irl)) -- interval [-5,5] for weights
         irl1 = drop totalunits irl
         randomWeights1 = [(take (inp*hid) randomWeights),(drop (inp*hid) randomWeights)]

-- decide what zone user is in, and assign to appropriate group of elevators
{-
dcaSubRuleBatch :: (Int, Int, Int) -> Float -> Float -> [Float] -> [Luser] -> [[[Float]]] -> [LiftState] -> [Char] -> Float -> ([Float], [[Luser]],[[[Float]]], Float)
dcaSubRuleBatch arch1 eta1 gamma1 irl             [] weights2 lS phase1 _ =
   let (irl2, plistLocal2, weights1, reward1) = dcaSubRule arch1 eta1 gamma1 irl [] weights2 lS phase1
   in  (irl2, plistLocal2 ,weights1, reward1)
dcaSubRuleBatch arch1 eta1 gamma1 irl newrandomplist weights2 lS phase1 _ =
   let (irl2, plistLocal2, weights1, reward1) = dcaSubRule arch1 eta1 gamma1 irl [head newrandomplist] weights2 lS phase1
       -- update lS with plistLocal2
       liftSpecific1 = updPlistsafterAsg plistLocal2 lS
   in  (dcaSubRuleBatch arch1 eta1 gamma1 irl2 (tail newrandomplist) $! weights1) liftSpecific1 phase1 $! reward1
-}
dcaSubRuleBatch :: ProgramState -> [Float] -> [Luser] -> ([Float], [[Luser]],[[[Float]]])
dcaSubRuleBatch pS irl [] =
   let (irl2, plistLocal2, weights1, reward1) = dcaSubRule pS irl []
   in  (irl2, plistLocal2 ,weights1)
dcaSubRuleBatch pS irl newrandomplist =
   let (irl2, plistLocal2, weights1, reward1) = dcaSubRule pS irl [head newrandomplist]
       -- update lS with plistLocal2
       liftSpecific1 = updPlistsafterAsg plistLocal2 (liftSpecific pS)
       weights2 = seq weights1 weights1
       pS_new = pS { weights = weights2, liftSpecific = liftSpecific1}
   in  dcaSubRuleBatch pS_new irl2 (tail newrandomplist)

dcaSubRule :: ProgramState -> [Float] -> [Luser] -> ([Float], [[Luser]], [[[Float]]], Float)
dcaSubRule pS irl [] =
   dcaSubRule1 pS irl [] (weights pS) 1000 1 ([], [], [], 0)
   where arch1 = arch pS
         eta1  = eta pS
         gamma1 = gamma pS
         weights1 = weights pS
         lS = liftSpecific pS
         phase1 = phase pS
dcaSubRule pS irl newrandomplist@(luser1:t)
   -- if passenger wants to go to floor 1, ignore
   | (arriv luser1)==1.0 =
        dcaSubRule1 pS irl [] (weights pS) 1000 1 ([], [], [], 0)
   -- if user on skylobby, floor 71 PURE DOWN TRAFFIC ONLY SOLUTION
   | ((elem (arriv luser1) zone12) && ((temp luser1)/=0.0 )) || ((elem (arriv luser1) zone12) && (elem (dest luser1) zone12)) =
        dcaSubShuttle2 pS irl newrandomplist
   -- if user on skylobby, floor 41 PURE DOWN TRAFFIC ONLY SOLUTION
   | ((elem (arriv luser1) zone11) && ((temp luser1)/=0.0 )) || ((elem (arriv luser1) zone11) && (elem (dest luser1) zone11)) =
        dcaSubShuttle pS irl newrandomplist
   -- if arrival in zone n (and beneath floor 41) than assign to zone n
   | (elem (arriv luser1) [1..40]) =
        dcaSubRule1 pS irl newrandomplist (weights pS) (cal luser1) 1 ([], [], [], 0)
   -- super-zone 1
   | (elem (arriv luser1) [41..70]) =
        let temp2 = dest luser1
            luser2 = luser1 {dest = 41, temp = temp2}
        in  if   elem (dest luser1) [1..40] -- if passenger goes to a lower segment, change tempfloor
            then dcaSubRule1 pS irl (luser2:t)     (weights pS) (cal luser1) 1 ([], [], [], 0)
            else dcaSubRule1 pS irl newrandomplist (weights pS) (cal luser1) 1 ([], [], [], 0)
   -- super-zone 2
   | (elem (arriv luser1) [71..100]) =
        let temp2 = dest luser1
            luser2 = luser1 {dest = 71, temp = temp2}
        in  if   elem (dest luser1) [1..70] -- if passenger goes to a lower segment, change tempfloor
            then dcaSubRule1 pS irl (luser2:t)     (weights pS) (cal luser1) 1 ([], [], [], 0)
            else dcaSubRule1 pS irl newrandomplist (weights pS) (cal luser1) 1 ([], [], [], 0)
   | otherwise = error "can't assign new passenger"
   where -- super-zone 0
         zones =  [1..100]
         zone1 =  calcZone 1 -- take 10 zones
         zone2 =  calcZone 2 -- take 10 (drop 10 zones)
         zone3 =  calcZone 3 -- take 10 (drop 20 zones)
         zone4 =  calcZone 4 -- take 10 (drop 30 zones)
         -- super-zone 1
         zone5 =  calcZone 5 -- take 10 (drop 40 zones)
         zone6 =  calcZone 6 -- take 10 (drop 50 zones)
         zone7 =  calcZone 7
         -- super-zone 2
         zone8 =  calcZone 8
         zone9 =  calcZone 9
         zone10 = calcZone 10
         -- shuttles
         zone11 = calcZone 11
         zone12 = calcZone 12
         arch1 = arch pS
         eta1  = eta pS
         gamma1 = gamma pS
         weights1 = weights pS
         lS = liftSpecific pS
         phase1 = phase pS
         cal luser3 = (ceiling ((arriv luser3)/10))

dcaSubShuttle :: ProgramState -> [Float] -> [Luser] -> ([Float], [[Luser]], [[[Float]]], Float)
dcaSubShuttle pS irl (luser1:t)
   | (temp luser1 == 0.0) =
        performdcaSubRule1 luser1
   | (arriv luser1 == 1) && (temp luser1 > 40) && (temp luser1 < 71) =
        let luser2 = luser1 {dest = 41}
        in  performdcaSubRule1 luser2
   | (arriv luser1 == 1) && (temp luser1 > 70) =
        let luser2 = luser1 {dest = 71}
        in  performdcaSubRule1 luser2
   | (arriv luser1 == 41) && (temp luser1 < 41) =
        let luser2 = luser1 {dest = 1}
        in  performdcaSubRule1 luser2
   | (arriv luser1 == 41) && (temp luser1 > 70) =
        let luser2 = luser1 {dest = 71}
        in  performdcaSubRule1 luser2
   | (arriv luser1 == 71) && (temp luser1 < 71) && (temp luser1 > 40) =
        let luser2 = luser1 {dest = 41}
        in  performdcaSubRule1 luser2
   | (arriv luser1 == 71) && (temp luser1 < 41) =
        let luser2 = luser1 {dest = 1}
        in  performdcaSubRule1 luser2
   where performdcaSubRule1 luser2 = dcaSubRule1 pS irl (luser2:t) (weights pS) 11 1 ([], [], [], 0) -- arch1 eta1 gamma1 irl (luser2:t) weights1 lS phase1 11 1 ([], [], [], 0)
dcaSubShuttle _ _ _ = error "dcaSubShuttle"

dcaSubShuttle2 :: ProgramState -> [Float] -> [Luser] -> ([Float], [[Luser]], [[[Float]]], Float)
dcaSubShuttle2 pS irl newrandomplist@(luser1:t)
   | (temp luser1 == 0.0) =
        dcaSubRule1 pS irl newrandomplist (weights pS) 12 1 ([], [], [], 0)
   | (arriv luser1 == 71) && (temp luser1 == 1) =
        let luser2 = luser1 {dest = 1}
        in  dcaSubRule1 pS irl (luser2:t) (weights pS) 12 1 ([], [], [], 0)
   | otherwise = error ("cannot assign within zone 12")
dcaSubShuttle2 _ _ [] = error "dcaSubShuttle2"

-- index indicates the index of zones that is assigned the new passenger, counter gives the current index
dcaSubRule1 :: ProgramState -> [Float] -> [Luser] -> [[[Float]]] -> Int -> Int -> ([Float], [[Luser]], [[[Float]]], Float) -> ([Float], [[Luser]], [[[Float]]], Float)
dcaSubRule1 pS irl newrandomplist weights1 index counter (o1, o2, o3, o4)
  | (liftSpecific pS)==[] =
        (o1, reverse o2, reverse o3, o4)
  | otherwise =
        let (irl1, [plistLocalA1, plistLocalB1], weightsAB1, rewardAB1) =
              (dcaSubNN pS irl (if counter==index then newrandomplist else []) (weights1!!0) (calcZone counter) ((lS!!0), (lS!!1)))
              -- (dcaSubNN arch1 eta1 gamma1 (calcZone counter) irl (if counter==index then newrandomplist else []) (weights1!!0) ((lS!!0), (lS!!1)) phase1)
        in let par6 = drop 1 weights1
               par7 = drop 2 lS
               par10 = counter + 1
               par11_2 = plistLocalB1 : plistLocalA1 : o2 -- ++ [plistLocalA1, plistLocalB1]
               par11_3 = weightsAB1 : o3 -- ++ [weightsAB1]
               par11_4 = o4 + rewardAB1
           in sometimesHyperStrict counter (arch1,eta1,gamma1,newrandomplist, par6) $
              sometimesHyperStrict counter (par7,phase1,index,par10,par11_2) $
              sometimesHyperStrict counter (par11_3,par11_4) $
           dcaSubRule1 (pS {arch = arch1, eta = eta1, gamma = gamma1, weights = par6, liftSpecific = par7, phase = phase1}) irl1 newrandomplist par6 index par10 ( irl1, par11_2, par11_3, par11_4) -- arch1 eta1 gamma1 irl1 newrandomplist par6 par7 phase1 index par10 ( irl1, par11_2, par11_3, par11_4)
  where arch1 = arch pS
        eta1  = eta pS
        gamma1 = gamma pS
        lS = liftSpecific pS
        phase1 = phase pS

allZones :: [[Float]]
allZones =
    [[1,2,3,4,5,6,7,8,9,10]
    ,[1,11,12,13,14,15,16,17,18,19,20]
    ,[1,21,22,23,24,25,26,27,28,29,30]
    ,[1,31,32,33,34,35,36,37,38,39,40]
    ,[41,42,43,44,45,46,47,48,49,50]
    ,[41,51,52,53,54,55,56,57,58,59,60]
    ,[41,61,62,63,64,65,66,67,68,69,70]
    ,[71,72,73,74,75,76,77,78,79,80]
    ,[71,81,82,83,84,85,86,87,88,89,90]
    ,[71,91,92,93,94,95,96,97,98,99,100]
    ,[1,41]
    ,[1,71]
    ]

calcZone :: Int -> [Float]
calcZone counter =
    allZones !! (counter -1)

dcaSubNN :: ProgramState -> [Float] -> [Luser] -> [[Float]] -> [Float] -> (LiftState, LiftState) -> ([Float], [[Luser]], [[Float]], Float)
dcaSubNN pS irl [] weights1 zone (stateLiftA, stateLiftB) =
   let plistLocal2s1 = [(plistLocal stateLiftA), (plistLocal stateLiftB)]
       floorinputsA = convertPasgToFloors (plistLocal stateLiftA) zone
       floorinputsB = convertPasgToFloors (plistLocal stateLiftB) zone
       -- reward = trace (show ((calcReward floorinputsA) + (calcReward floorinputsB))) (calcReward floorinputsA) + (calcReward floorinputsB)
       reward = calcReward1 (plistLocal stateLiftA) (plistLocal stateLiftB) -- (calcReward floorinputsA) + (calcReward floorinputsB)
   in  (irl, plistLocal2s1, weights1, reward)
dcaSubNN pS irl newrandomplist@(luser1:_) weights1 zone liftSpecific1@(stateLiftA, stateLiftB)
   | (phase pS) == "learn" =
      let  stateLiftA_new = stateLiftA {plistLocal = newPlistLocalA}
           stateLiftB_new = stateLiftB {plistLocal = newPlistLocalB}
           -- step 3
           amountnewpsgN_tp1 = 1
           (luser1_tp1:_) = (createNRandompsg amountnewpsgN_tp1 irl2)
           --   estimated next tick states, with new passenger assigned
           (stateLiftA_tp1_temp, _) = ola zone stateLiftA_new
           (stateLiftB_tp1_temp, _) = ola zone stateLiftB_new
           waittimeLiftA_tp1 = calcReward1 (plistLocal stateLiftA_tp1_temp) [] -- waitTimePerLift (plistLocal stateLiftA)
           waittimeLiftB_tp1 = calcReward1 (plistLocal stateLiftB_tp1_temp) [] -- waitTimePerLift (plistLocal stateLiftB)
           futureLoadA_tp1 = (1 / (1.1 + (24 - (load stateLiftA_tp1_temp) - fromIntegral (length (plistLocal stateLiftA_tp1_temp)))))
           futureLoadB_tp1 = (1 / (1.1 + (24 - (load stateLiftB_tp1_temp) - fromIntegral (length (plistLocal stateLiftB_tp1_temp)))))
           floorPosA_tp1 = floorPos stateLiftA_tp1_temp / 100
           floorPosB_tp1 = floorPos stateLiftB_tp1_temp / 100
           reldisA_tp1 = (floorPos stateLiftA_tp1_temp - arriv luser1_tp1) / 40 -- relative distance
           reldisB_tp1 = (floorPos stateLiftB_tp1_temp - arriv luser1_tp1) / 40
           arrivL_tp1 = arriv luser1_tp1 / 100
           destL_tp1  = dest  luser1_tp1 / 100
           directionA_tp1 = if (direction stateLiftA_tp1_temp)==Down then (-1) else 1
           directionB_tp1 = if (direction stateLiftB_tp1_temp)==Down then (-1) else 1
           allinputs_tp1 = [directionA_tp1, (load stateLiftA_tp1_temp), floorPosA_tp1, waittimeLiftA_tp1, futureLoadA_tp1, reldisA_tp1, (directionB_tp1), (load stateLiftB_tp1_temp), floorPosB_tp1, waittimeLiftB_tp1, futureLoadB_tp1, reldisB_tp1, arrivL_tp1, destL_tp1]
           -- allinputs =  [directionA,     (load stateLiftA),          floorPosA,     waittimeLiftA,     futureLoadA,     reldisA,     directionB,       (load stateLiftB),          floorPosB,     waittimeLiftB,     futureLoadB,     reldisB,     arrivL,     destL]
           -- allinputs =  [(direction stateLiftA),          (load stateLiftA),          (floorPos stateLiftA),          waittimeLiftA,     futureLoadA,     (direction stateLiftB),          (load stateLiftB),          (floorPos stateLiftB),          waittimeLiftB,     futureLoadB,     (arriv luser1), (dest luser1)]
           pair_weights_qvalues_tp1 = network1 weights1 allinputs_tp1 (arch pS)
           qvalues_tp1 = pair_weights_qvalues_tp1!!1
           maxQ_tp1 = maximum qvalues_tp1
           -- step 4
           estD = ((gamma pS)*maxQ_tp1) + reward -- estimated d; the target output that the nn agent must learn for this state
           integratedEstD = (take selectedLift qvalues) ++ [estD] ++ (drop (selectedLift + 1) qvalues) -- make a vector with estD in the place of the action that was chosen in s_t
           example = (allinputs, integratedEstD)
           newWeights = updateWeights example pair_weights_qvalues weights1 (arch pS) (eta pS)
           irl3 = drop amountnewpsgN_tp1 irl2
      in   (irl3, plistLocal2s, newWeights, reward)
   | (phase pS) == "run" =
      let  irl3 = irl2
      in   (irl3, plistLocal2s, weights1, reward)
   | (phase pS) == "SAL" =
      let  selectedLiftSAL = selectLiftSAL epsilon liftSpecific1
           plistLocal2sSAL = (take selectedLiftSAL updPlists) ++ [(updPlists!!selectedLiftSAL) ++ [head newrandomplist]] ++ (drop (selectedLiftSAL + 1) updPlists)
      in   (irl2, plistLocal2sSAL, weights1, reward)
   | (phase pS) == "SAA" =
      let  (stateLiftA1, stateLiftB1) = liftSpecific1
           commA = calcComm newrandomplist stateLiftA1
           commB = calcComm newrandomplist stateLiftB1
           selectedLiftSAA = selectLiftSAA epsilon commA commB
           plistLocal2sSAA = (take selectedLiftSAA updPlists) ++ [(updPlists!!selectedLiftSAA) ++ [head newrandomplist]] ++ (drop (selectedLiftSAA + 1) updPlists)
      in   (irl2, plistLocal2sSAA, weights1, reward)
   where [epsilon] = take 1 irl
         irl2 = drop 1 irl
         waittimeLiftA = calcReward1 (plistLocal stateLiftA) [] -- waitTimePerLift (plistLocal stateLiftA)
         waittimeLiftB = calcReward1 (plistLocal stateLiftB) [] -- waitTimePerLift (plistLocal stateLiftB)
         futureLoadA = (1 / (1.1 + (24 - (load stateLiftA) - fromIntegral (length (plistLocal stateLiftA)))))
         futureLoadB = (1 / (1.1 + (24 - (load stateLiftB) - fromIntegral (length (plistLocal stateLiftB)))))
         floorPosA = floorPos stateLiftA / 100
         floorPosB = floorPos stateLiftB / 100
         reldisA = (floorPos stateLiftA - arriv luser1) / 40 -- relative distance
         reldisB = (floorPos stateLiftB - arriv luser1) / 40
         arrivL = arriv luser1 / 100
         destL  = dest  luser1 / 100
         directionA = if (direction stateLiftA)==Down then (-1) else 1
         directionB = if (direction stateLiftB)==Down then (-1) else 1
         -- allinputs = [(direction stateLiftA), (load stateLiftA), (floorPos stateLiftA), waittimeLiftA, futureLoadA, (direction stateLiftB), (load stateLiftB), (floorPos stateLiftB), waittimeLiftB, futureLoadB, (arriv luser1), (dest luser1)]
         allinputs = [directionA, (load stateLiftA), floorPosA, waittimeLiftA, futureLoadA, reldisA, directionB, (load stateLiftB), floorPosB, waittimeLiftB, futureLoadB, reldisB, arrivL, destL]
         -- step 1
         pair_weights_qvalues = network1 weights1 allinputs (arch pS)
         qvalues = pair_weights_qvalues!!1
         -- step 2
         selectedLift = selectLift qvalues epsilon (tick pS) (maxticks pS)-- returns the index of the elevator in liftSpecific1: 0 = liftA, 1 = liftB
         floorinputsA = convertPasgToFloors (plistLocal stateLiftA) zone
         floorinputsB = convertPasgToFloors (plistLocal stateLiftB) zone
         -- reward1 = (calcReward floorinputsA) + (calcReward floorinputsB) -- sum of lift rewards= negative sum of all squares of all passenger waittimes
         reward = calcReward1 (plistLocal stateLiftA) (plistLocal stateLiftB)
         -- reward = trace (show reward1) reward1
         updPlists = [plistLocal stateLiftA, plistLocal stateLiftB]-- [updPlistA, updPlistB]
         -- the passenger (newrandomplist) is assigned to 1 updPlist to, the resulting lists are the newPlistLocals
         --  use "take ++ !! ++ drop"-method to add new passengers to the plistLocal of the winning lift
         plistLocal2s@[newPlistLocalA, newPlistLocalB] = (take selectedLift updPlists) ++ [(updPlists!!selectedLift) ++ [head newrandomplist]] ++ (drop (selectedLift + 1) updPlists)
dcaSubNN _ _ _ _ _ _ = error "dcaSubNN"

calcReward1 :: [Luser] -> [Luser] -> Float
calcReward1 list1 list2 =
   let l1 = map wait list1
       l2 = map wait list2
       l3 = l1 ++ l2
       squaredl = map kwadraat l3
       meanl = sum squaredl -- / (fromIntegral (length l3) :: Float)
       rootl = sqrt meanl
   in  (- rootl) / 100000
{-
       if (length l3) == 0
       then 0
       else (- rootl) / 10000
-}

integrateD :: t -> [t] -> [Char] -> [t]
integrateD estD [x,y] sA
   | sA == "S" = [estD,y]
   | sA == "C" = [x,estD]
integrateD _ _ _ = error "integrateD"

-- choose between exploit or explore
-- selectLift :: (Num a1, Fractional a, Ord a, Ord a11) => [a11] -> a -> Int -> Int -> a1
selectLift :: [Float] -> Float -> Int -> Int -> Int
selectLift qvalues epsilon ticks maxticks
   | epsilon < epsilonThreshold = exploitSelectLift qvalues 0  -- if epsilon is below treshold, than greedy so exploit
   | epsilon < (epsilonThreshold + 0.5*epsilonThreshold) = 0   -- else explore and choose elevator 0 randomly
   | otherwise = 1                                             -- else explore and choose elevator 1 randomly
   where epsilonThreshold = selectLiftThreshold ((fromIntegral ticks)::Float) ((fromIntegral maxticks)::Float)

selectLiftThreshold :: Float -> Float -> Float
selectLiftThreshold ticks maxticks
   | ticks < hmticks =
      0.5
   | otherwise =
      let thres =  0.5 + (0.5*( (ticks - hmticks) / hmticks) )
      in  thres
   where hmticks = 0.5*maxticks

selectLiftSAL :: Float -> (LiftState, LiftState) -> Int
selectLiftSAL epsilon (stateLiftA, stateLiftB)
   | (lA < lB) || ((lA == lB) && epsilon < 0.5) = 0
   | (lA > lB) || ((lA == lB) && epsilon > 0.5) = 1
   where lA = length (plistLocal stateLiftA)
         lB = length (plistLocal stateLiftB)
selectLiftSAL _ (_, _) = error "selectedLiftSAL"

selectLiftSAA :: (Num t, Fractional a1, Ord a1, Ord a) => a1 -> a -> a -> t
selectLiftSAA epsilon commA commB
   | (commA < commB) || ((commA == commB) && epsilon < 0.5) = 0
   | (commA > commB) || ((commA == commB) && epsilon > 0.5) = 1
selectLiftSAA _ _ _ = error "selectLiftSAA"

exploitSelectLift :: (Num a1, Ord a) => [a] -> a1 -> a1
exploitSelectLift [] 0 = error "empty q-value list"
exploitSelectLift [] _ = error "no highest q-value found"
exploitSelectLift qvalues n
   | (head qvalues)==(maximum qvalues) = n
   | otherwise = exploitSelectLift (tail qvalues) (n+1)

dcaPrinter :: Int -> [Luser] -> Float -> [LiftState] -> IO ()
dcaPrinter ticks newrandomplist reward liftSpecific1 =
   do
   putStr ("Tick " ++ (show ticks) ++"    ")
   putStr ("Reward (- sum(waittimes^2)): " ++ (show reward)++"    ")
   putStr ("New passengers " ++ (show newrandomplist) ++"\n")
   dcaPrinter1 liftSpecific1 0
   
dcaPrinter1 :: [LiftState] -> Int -> IO ()
dcaPrinter1 [] _ =
   do
   putStr "========================================================\n"
dcaPrinter1 (stateLift:stateLifts) n =
   do
   putStr "----------------------------------------------\n"
   putStr ("Elevator " ++ (show n))
   putStr ("     Floor " ++ (show (floorPos stateLift))++"    ")
   putStr ("After taking action " ++ (show (action stateLift))++"    ")
   putStr ("Load " ++ (show (load stateLift))++"    ")
   putStr ("Direction " ++ (show (direction stateLift)) ++"\n")
   putStr ("Passengers waiting for this lift: " ++ (show (plistLocal stateLift))++"\n")
   putStr ("Passengers aboard this lift: " ++ (show (plistBoarded stateLift))++"\n")
   dcaPrinter1 stateLifts (n + 1)

dcaPrinter2 :: Int -> [LiftState] -> String
dcaPrinter2 ticks liftSpecific1 =
   let pre1 = ("Tick " ++ (show ticks) ++"    ")
   in  pre1 ++ (dcaPrinter3 liftSpecific1 0)

dcaPrinter3 :: [LiftState] -> Int -> String
dcaPrinter3 [] _ =
   "========================================================\n"
dcaPrinter3 (stateLift:stateLifts) n =
   let a1 = "----------------------------------------------\n"
       a2 = ("Elevator " ++ (show n))
       a3 = ("     Floor " ++ (show (floorPos stateLift))++"    ")
       a4 = ("After taking action " ++ (show (action stateLift))++"    ")
       a5 = ("Load " ++ (show (load stateLift))++"    ")
       a6 = ("Direction " ++ (show (direction stateLift)) ++"\n")
       a7 = ("Passengers waiting for this lift: " ++ (show (plistLocal stateLift))++"\n")
       a8 = ("Passengers aboard this lift: " ++ (show (plistBoarded stateLift))++"\n")
       aT = a1 ++ a2 ++ a3 ++ a4 ++ a5 ++ a6 ++ a7 ++ a8
   in aT ++ dcaPrinter3 stateLifts (n + 1)

optimalComm :: (Num a, Ord a1) => [a1] -> [a]
optimalComm [] = []
optimalComm list
   | ((head list)==(minimum list)) = 1:(replicate ((length.tail) list) 0)
   | otherwise = 0:(optimalComm (tail list) )

-- if load increases, calcComm increases
-- if relative distance increases, calcComm increases
-- if direction is wrong for the waiting passenger, give penalty
calcComm :: [Luser] -> LiftState -> Float
calcComm newPlist stateLift
   | (newPlist == []) = 0
   | (direction stateLift == Up) && (waitingDir <= 0) = subtotal     -- direction same as waiting
   | (direction stateLift == Down) && (waitingDir >= 0) = subtotal
   | (direction stateLift == Up) && (waitingDir > 0)  = subtotal + 2.0 -- direction different from waitingDir, give penalty
   | (direction stateLift == Down) && (waitingDir < 0)  = subtotal + 2.0
   | otherwise = error ("calcComm can't find direction")
   where subtotal = ((distance * load1)* waitingTime)
         waitingDir = (floorPos stateLift) - arrivalFloor
         distance = (abs ((floorPos stateLift) - arrivalFloor)) + 1.0   -- addition of one, because otherwise a value of zero, would render the other parameters useless
         load1 = (load stateLift) + 1.0
         -- invLoad  = 1.0 / (1.0 + (load stateLift))
         arrivalFloor = arriv (head newPlist) -- (head (head newPlist))
         waitingTime = fromIntegral (length (plistLocal stateLift)) + 1.0

updateTest :: [Luser] -> [[Luser]]
updateTest plist = a:(updateTest a)
   where a = (updatePlist plist)

-- increase all wait values with one
updatePlist :: [Luser] -> [Luser]
updatePlist passengers = map (\passenger -> passenger {wait = wait passenger + 1}) passengers

-- one lift agent; controls the updating of the states of the lift, and its direction
ola :: [Float] -> LiftState -> (LiftState, [Luser])
ola zone stateLift =
   let selectedAction = calcAction stateLift -- (floorPos stateLift) (load stateLift) (plistLocal stateLift) (plistBoarded stateLift) (holdPos stateLift)
       newPosition = calcNewpoint (floorPos stateLift) selectedAction (direction stateLift) zone
       -- calculate the updated plist and plistBoarded and what passengers just entered (i.e. stopped waiting)
       (newPlistBoarded, newPlistLocal, newlyBoarded, holdposition) = calcBoarded selectedAction stateLift -- (floorPos stateLift) (plistBoarded stateLift) (plistLocal stateLift) (holdPos stateLift)
       -- calculate the updated load etc.
       newLoad = fromIntegral (length newPlistBoarded)
       newHfloor = calcHFloor (plistLocal stateLift)
       newDirection = calcDir newPosition (direction stateLift) newPlistLocal newPlistBoarded newHfloor newLoad zone
       -- correct counters for all waiting users
       updPlistLocal = updatePlist newPlistLocal
       stateLift1 = LiftState { direction = newDirection, load = newLoad, plistLocal = updPlistLocal, plistBoarded = newPlistBoarded, floorPos = newPosition, action = selectedAction, holdPos = holdposition } -- the new statelift, at the end of this funciton filled with new values
   in (stateLift1, newlyBoarded)

------------------ ola helper functions        BEGIN
calcDir :: (Num a) => Float -> Direction -> [Luser] -> [Luser] -> Float -> a -> [Float] -> Direction
calcDir floorPos1 direction1 plist plistBoarded1 hfloor load1 zone
   | load1 == 24 = Down      -- nobody wants to go up, and lift full, then go down
   | floorPos1==maximum zone && (plist==[] || plistBoarded1==[]) = Down -- if on highest floor and people waiting or on board, go down
   | direction1==Up =
        if any (\x -> (arriv x)>=floorPos1) plist then Up -- if going up and people waiting above (OR ON SAME FLOOR) continue going up
        else if amountPsgUp floorPos1 plistBoarded1>0 then Up  -- if any passenger on board wants to go up and direction1 is up, continue up
        else if hfloor <= floorPos1 && hfloor/=1 then Down -- nobody onboard wants to go up or someone is waiting below, and no higher waiting passengers
        else Up
   | direction1==Down = -- AFIE: tip: data Direction = Up | Down
        if any (\x -> (arriv x)<=floorPos1) plist then Down -- if going down and people waiting below (OR ON SAME FLOOR) continue going down
        else if amountPsgDown floorPos1 plistBoarded1>0 then Down -- if any passenger on board wants to go up and direction1 is up, continue up
        else Up
calcDir _ _ _ _ _ _ _ = error "calcDir"

amountPsgUp :: Float -> [Luser] -> Int
amountPsgUp floorPos1 plistBoarded1 = -- calculate amount of passengers that are onboard and want to go up
   let a = map (\x -> (dest x)>floorPos1) plistBoarded1
   in  length (filter (==True) a)

amountPsgDown :: Float -> [Luser] -> Int
amountPsgDown floorPos1 plistBoarded1 =
   let a = map (\x -> (dest x)<floorPos1) plistBoarded1
   in  length (filter (==True) a)

-- create new passengers in 20% of the ticks (i.e. 1 every 5 ticks or 0.2 passengers per tick)
newrandomp :: [Float] -> ([Float], [Luser])
newrandomp irl =
   let amountnewpsgN = 1 -- amount of new passengers to create this step
       newrandomplist = createNRandompsg amountnewpsgN (tail irl) -- list of passengers, each passenger of form [arrival, destination, 0 , 0]
   in  if (head irl) > 0.2
       then ((tail irl), [])
       else ((drop 2 irl), newrandomplist)

createNRandompsg :: Int -> [Float] -> [Luser]
createNRandompsg 0 _ = []
createNRandompsg n irl =
   let arrival = fromIntegral (((round (98*(irl!!0)))::Integer)+2) -- create arrival floors 2 up to 100 (peak-down traffic)
       destination = 1
       luser1 = Luser { arriv = arrival, dest = destination, temp = 0, wait = 0 }
   in  luser1:(createNRandompsg (n-1) (drop 1 irl))   -- list of passengers, each passenger of form [arrival, destination, 0 , 0]

-- given a plistLocal and a zone this function returns the sum of squared waittimes per floor
convertPasgToFloors :: [Luser] -> [Float] -> [Float]
convertPasgToFloors plist zone =
   map convertOne zone
   where convertOne floor1 = loop plist 0
           where
            loop [] sumSoFar = sumSoFar
            loop (passenger:passengers) sumSoFar =
                if arriv passenger == floor1 then
                    loop passengers $! (sumSoFar + kwadraat (wait passenger))
                else
                    loop passengers sumSoFar

                -- er stond achter convertOne ... = : sum [ kwadraat (wait x) | x <- plist, arriv x == floor1 ]


kwadraat :: Float -> Float
kwadraat x = x * x

plistToTotalwaitpfloor :: [Luser] -> [Float] -> [Float]
plistToTotalwaitpfloor _ [] = []
plistToTotalwaitpfloor plist zone =
   let pasgOnFloor = (filter (\x -> (arriv x)==(head zone)) plist)
       waittimes = map (\x -> (wait x)) pasgOnFloor
   in  (sum waittimes):(convertPasgToFloors plist (tail zone))

waitTimePerLift :: [Luser] -> Float
waitTimePerLift plist =
   let waittimelist = map (\x -> (wait x)) plist
   in  sum waittimelist

-- if there are no passengers waiting, HFloor, the highest floor with waiting passengers is 1
calcHFloor :: [Luser] -> Float
calcHFloor [] = 1
calcHFloor plist =
   maximum (map (\x -> (arriv x)) plist)

-- if there are no passengers waiting, LFloor, the floor with the longest waiting passenger is 1
-- calcLFloor :: [[Luser]] -> a
calcLFloor [] = 1
calcLFloor plist =
   ((maximum (map (\x -> [x!!3,x!!0]) plist))!!1)

-- the negative of the sum over floorinputs, with floorinput the list of squared the waittimes per floor,
-- based on the plist of one elevator
-- calcReward :: (Num a) => [a] -> a
calcReward :: [Float] -> Float
calcReward cptf =
   let lcptf = fromIntegral (length cptf) :: Float
   in  - ( sqrt ((sum cptf) / lcptf) )

-- boarding and exiting only allowed when selected action is "S" (stop)
-- after a change in boarding/exiting, output a hold-position value, calculated from the amount of boarded/exited passengers.
-- calcBoarded action floorPos plistBoarded plist holdposition
calcBoarded :: Action -> LiftState -> ([Luser], [Luser], [Luser], Int)
calcBoarded action1 liftState
   | holdposition > 0 = (plistBoarded1, plist, [], (holdposition - 1))
   | action1==Continue = (plistBoarded1, plist, [], 0)
   | action1==Stop     = ((boardedAfterBoarding!!0), ((boardedAfterBoarding!!1)++cantBoard), newlyBoarded, holdposition1) -- pair: boarded, (updated plist)
   where floorPos1     = (floorPos liftState)
         plistBoarded1 = (plistBoarded liftState)
         plist        = plistLocal liftState
         holdposition = holdPos liftState
         boardedAfterExiting = filter (\x -> (dest x)/=floorPos1) plistBoarded1
         canBoard = (filter (\x -> (arriv x)==floorPos1) plist)  -- are on same floor as lift -- sorting this so that the longest waiting passenger may go fist would probably decrease average wait-time, but is not practically implementable.
         cantBoard = (filter (\x -> (arriv x)/=floorPos1) plist) -- are not on same floor as lift
         boardedAfterBoarding = addOneByOneToMaximum boardedAfterExiting canBoard []
         newlyBoarded = boardedAfterBoarding!!2
         holdposition1 = (15*(length (filter (\x -> (dest x)==floorPos1) plistBoarded1))) + (15*(length newlyBoarded))
calcBoarded _ _ = error "calcBoarded"

-- returns a list: [boardedUsers, usersThatWanttoButcantgeton, newlyBoardedUsers]
addOneByOneToMaximum :: [Luser] -> [Luser] -> [Luser] -> [[Luser]]
addOneByOneToMaximum boarded wantToBoard newlyBoarded
   | wantToBoard==[] = [boarded, [], newlyBoarded]
   | (length boarded)==maxload = [boarded, wantToBoard, newlyBoarded]
   | otherwise = addOneByOneToMaximum (boarded ++ [head wantToBoard]) (tail wantToBoard) (newlyBoarded ++ [head wantToBoard])
   where maxload = 24


-- check if action doesn't break any constraints
calcNewpoint :: (Ord a, Fractional a) => a -> Action -> Direction -> [a] -> a
calcNewpoint oldFloor Stop direction1 zone = oldFloor
calcNewpoint oldFloor Continue direction1 zone
    | direction1 == Up = if oldFloor /= topfloor then
                            oldFloor + 0.25 -- go up one quarter floor per tick
                         else
                            oldFloor
    | direction1 == Down = if oldFloor /= botfloor then
                            oldFloor - 0.25 -- go down one quarter floor per tick
                           else
                            oldFloor
    where topfloor = maximum zone
          botfloor = minimum zone
calcNewpoint _ _ _ _  = error ("calcNewPoint")

-- first check if any constraint holds, else explore/exploit to choose an action
-- simplified to: ... -> S, ... -> S, otherwise C  (because no epsilon greedy selection without neural network)
-- calcAction :: Float -> t -> [Luser] -> [Luser] -> Action
-- always stop if someone wants to get on or off, unless lift is full
calcAction :: LiftState -> Action
calcAction liftState -- pos load plist plistBoarded holdposition
   | holdposition > 0                  = Stop -- waiting for passengers to board/exit
   | (wanttogeton/=[]) && (load1 < 24) = Stop -- always stop if someone wants to get on (because of DCA, once a user is assigned, it must always be picked up, A neural net may be implemented to choose whether or not to pick up someone, instead of making at mandatory, to improve performance)
   | (wanttogetoff/=[])                = Stop -- always stop if someone wants to get off
   | otherwise = Continue
   where pos = floorPos liftState
         load1 = load liftState
         plist = plistLocal liftState
         plistBoarded1 = plistBoarded liftState
         holdposition = holdPos liftState
         wanttogeton  = (filter (\x -> (arriv x)==pos) plist)
         wanttogetoff = (filter (\x -> (dest x)==pos) plistBoarded1)
------------------ olaLearn helper functions        END

-- End Reinforcement Learning Agent


-- create initial weights: all set to 0
iW :: Float
iW = 1
initWeights :: (Int,Int,Int) -> [[Float]]
initWeights (ninput,nhidden,noutput) =
   (replicate (ninput*nhidden) iW):(replicate (nhidden*noutput) iW):[]

-- calculating the output
-- e.g. every hidden unit takes the sum of the products of all its preceding units
addBias :: (Num a) => [([a], t)] -> [([a], t)]
addBias example = map (\(a,b) -> ((a++[1]),b)) example

-- network gives as output, only the output of the output layer
network :: [[Float]] -> [Float] -> (Int,Int,Int) -> [Float]
network weights1 input architecture =
   (network1 weights1 input architecture)!!1

-- network1 gives as output a pair of the outputs of the hidden layer and of the output layer
network1 :: [[Float]] -> [Float] -> (Int,Int,Int) -> [[Float]]
network1 weights1 input (ninput,nhidden,_) =
   [outputHiddenUnits,outputOutputUnits]
   where outputHiddenUnits = hiddenOutputs (weights1!!0) (input++[1]) {- input + bias -} ninput
         outputOutputUnits = outputOutputs (weights1!!1) ((init outputHiddenUnits)++[1]) {- hidden + bias -} nhidden

outputOutputs :: [Float] -> [Float] -> Int -> [Float]
outputOutputs [] _ _ = []
outputOutputs weights1 hidden nhidden =
   (calcPerceptron1 (take nhidden weights1) hidden):nextOutput
   where nextOutput = outputOutputs (drop nhidden weights1) hidden nhidden

hiddenOutputs :: [Float] -> [Float] -> Int -> [Float]
hiddenOutputs [] _ _ = []
hiddenOutputs weights1 input ninput =
   (calcPerceptron (take ninput weights1) input):nextHidden
   where nextHidden = hiddenOutputs (drop ninput weights1) input ninput

calcPerceptron :: [Float] -> [Float] -> Float
calcPerceptron weights1 inputs =
   sigmoid (sum (zipWith (*) weights1 inputs))

calcPerceptron1 :: [Float] -> [Float] -> Float
calcPerceptron1 weights1 inputs =
   summa
   where products = zipWith (*) weights1 inputs
         summa = sum products

sigmoid :: Float -> Float
sigmoid i =
   1 / (1 + exp (-i))

-- the error function that should be minimized
errors :: ([Float], [Float]) -> [[Float]] -> (Int, Int, Int) -> Float
errors (input,toutput) weights1 arch1 =
   0.5 * (sum sqdif)
   where actualOutput = network weights1 input arch1
         difference = zipWith (-) toutput actualOutput
         sqdif = map (^(2::Integer)) difference

errorsOverExamples :: [([Float], [Float])] -> [[Float]] -> (Int, Int, Int) -> [Float]
errorsOverExamples [] _ _ = []
errorsOverExamples examples weights1 arch1 =
   (errors (head examples) weights1 arch1):(errorsOverExamples (tail examples) weights1 arch1)

-- Backpropagation
-- ===============
-- calculate for each output i its delta_i
deltaI :: Float -> Float -> Float
deltaI o t =
   (t-o)

-- calculate for each hidden j its delta_j, wL2 is the list: weights of level 2, i.e. between hidden and output
wXDeltaI :: (Num b) => [b] -> [b] -> [b]
wXDeltaI wL2 dI =
   zipWith (*) wL2 dI

deltaJ :: Float -> [Float] -> Float
deltaJ o wXD =
   o*(1-o)*(sum wXD)

-- calculate for each weight ji its capital_delta_ji
cDeltaJI :: (Num a) => a -> a -> a -> a
cDeltaJI delta input eta1 =
   eta1*delta*input

-- update each weight with its capital_delta
newWeight :: (Num a) => a -> a -> a -> a -> a
newWeight delta x w eta1 =
   w + cDeltaJI delta x eta1

errors1 :: (Fractional b) => [b] -> [b] -> b
errors1 networkOutput target =
   0.5 * (sum sqdif)
   where difference = zipWith (-) target networkOutput
         sqdif = map (^(2::Integer)) difference

updateWeights :: ([Float], [Float])-> [[Float]] -> [[Float]] -> (Int, Int, Int) -> Float -> [[Float]]
updateWeights (input,target) network2 weights1 (nin,nhid,noutput) eta1 =
   [(concat nhw),(concat now)]
   where listOfDI = zipWith deltaI (network2!!1) target -- output deltas
         listOfwXDs1 = listOfwXDs listOfDI (weights1!!1) noutput
         listOfDJ = zipWith deltaJ (network2!!0) listOfwXDs1 -- hidden deltas
         inputOutput = network2!!0
         inputHidden = input
         nhw = newOHWeights listOfDJ (inputHidden ++ [1]) (weights1!!0) nin eta1 -- adding bias to inputs
         now = newOHWeights listOfDI ((init inputOutput) ++ [1]) (weights1!!1) nhid eta1 -- replace the last input by a bias

newOHWeights :: [Float] -> [Float] -> [Float] -> Int -> Float -> [[Float]]
newOHWeights [] _ [] _ _ = []
newOHWeights (hdListOfD:tlListOfD) inputs weights1 n etaL
    = newOHW1      hdListOfD inputs xs etaL
    : newOHWeights tlListOfD inputs ys n etaL
  where
    (xs, ys) = splitAt n weights1
newOHWeights [] _ (_:_) _ _ = error "newOHWeights"

newOHW1 :: Float -> [Float] -> [Float] -> Float -> [Float]
newOHW1 delta inputs weightsL etaL =
    zipWith (\input weight -> newWeight delta input weight etaL) inputs weightsL

-- list of delta_i, layer 2 weights, number of output units
listOfwXDs :: (Num a) => [a] -> [a] -> Int -> [[a]]
listOfwXDs _ [] _ = []
listOfwXDs listOfDI wL2 nout =
   (wXDeltaI (take nout wL2) listOfDI):(listOfwXDs listOfDI (drop nout wL2) nout)

