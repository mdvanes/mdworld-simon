module Migrateweights where
import List
import System

vervang :: Eq a => a -> a -> [a] -> [a]
vervang _ _ []    = []
vervang x y (h:t) = if x==h then y : vervang x y t else h : vervang x y t

addSeparator sep list
   | list == []        = []
   | (tail list) == [] = head list
   | otherwise         = (head list) ++ sep ++ (addSeparator sep (tail list))

migrationSub [filename] =
   do
   fileContents <- readFile filename
   let a = importParser fileContents
   putStr ("Filename: " ++ (show filename) ++ "\n")
   putStr ("Weights: " ++ (show a) ++ "\n")
   --
   let b = exportParser a
   putStr (show a)
   writeFile ("updatedweights_"++filename) b

-- import text files
importParser fileContents =
   let a = words (vervang '\n' ' ' fileContents)
       b = map (vervang '_' ' ') a
       c = map words b
       d = map (map (vervang ',' ' ')) c
       e = map (map words) d
       f = map (map (map read1)) e
   in  f

read1 string = read string :: Float  -- string ++ "1" --

exportParser weights =
   let a = map (map (map show)) weights
       b = map (map (addSeparator ",")) a
       c = map (addSeparator "_") b
       d = addSeparator "\n" c
   in  d

